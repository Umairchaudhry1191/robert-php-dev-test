<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTranslationUnitVersionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('translation_unit_versions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('translation_unit_id');
            $table->foreign('translation_unit_id')->references('id')->on('translation_units')->onDelete('cascade');
            $table->text('old_text');
            $table->timestamp('updated_at');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('translation_unit_versions');
    }
}

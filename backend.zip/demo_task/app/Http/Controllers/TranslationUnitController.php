<?php

namespace App\Http\Controllers;

use App\Models\TranslationUnit;
use Illuminate\Http\Request;

class TranslationUnitController extends Controller
{
    public function store(Request $request)
    {
        $translationUnit = TranslationUnit::create($request->all());
        return response()->json($translationUnit, 201);
    }

    public function index()
    {
        return TranslationUnit::all();
    }

    public function show($id)
    {
        return TranslationUnit::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $translationUnit = TranslationUnit::findOrFail($id);
        $translationUnit->update($request->all());
        return $translationUnit;
    }

    public function destroy($id)
    {
        $translationUnit = TranslationUnit::findOrFail($id);
        $translationUnit->delete();
        return 204; // No content
    }
}

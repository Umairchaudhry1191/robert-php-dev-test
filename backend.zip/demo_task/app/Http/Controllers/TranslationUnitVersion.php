<?php
namespace App\Http\Controllers;

use App\Models\TranslationUnit;
use App\Models\TranslationUnitVersion;
use Illuminate\Http\Request;

class TranslationUnitVersionController extends Controller
{
    public function create(Request $request)
    {
        $translationUnitVersion = TranslationUnitVersion::create($request->all());
        return response()->json($translationUnitVersion, 201);
    }

    public function index()
    {
        return TranslationUnitVersion::all();
    }

    public function show($id)
    {
        return TranslationUnitVersion::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $translationUnitVersion = TranslationUnitVersion::findOrFail($id);
        $translationUnitVersion->update($request->all());
        return $translationUnitVersion;
    }

    public function destroy($id)
    {
        $translationUnitVersion = TranslationUnitVersion::findOrFail($id);
        $translationUnitVersion->delete();
        return 204; // No content
    }

}

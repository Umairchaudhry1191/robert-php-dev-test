<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TranslationUnit extends Model
{
    use HasFactory;

    protected $fillable = ['text', 'source_language', 'target_language', 'context'];

    public function versions()
    {
        return $this->hasMany(TranslationUnitVersion::class);
    }
}

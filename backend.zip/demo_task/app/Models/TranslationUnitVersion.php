<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TranslationUnitVersion extends Model
{
    use HasFactory;

    protected $fillable = ['translation_unit_id', 'old_text', 'updated_at'];

    public function translationUnit()
    {
        return $this->belongsTo(TranslationUnit::class);
    }
}

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TranslationUnitController;
use App\Http\Controllers\TranslationUnitVersionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
//create restful api for translation unit
Route::post('/translation_units', [TranslationUnitController::class, 'store']);
Route::get('/translation_units', [TranslationUnitController::class, 'index']);
Route::get('/translation_units/{id}', [TranslationUnitController::class, 'show']);
Route::put('/translation_units/{id}', [TranslationUnitController::class, 'update']);
Route::delete('/translation_units/{id}', [TranslationUnitController::class, 'destroy']);
//create restful api for translation unit version
// Route::post('/translation_unit_versions', [TranslationUnitVersionController::class, 'store']);
// Route::get('/translation_unit_versions', [TranslationUnitVersionController::class,  'index']);
// Route::get('/translation_unit_versions/{id}', [TranslationUnitVersionController::class, 'show']);
// Route::put('/translation_unit_versions/{id}', [TranslationUnitVersionController::class, 'update']);
// Route::delete('/translation_unit_versions/{id}', [TranslationUnitVersionController::class, 'destroy']);

